# Customer-Relation-Management
# Clone This Project git clone https://github.rudebaby254/django-Customer-Relation-Management.git
# When using vscode
# Go to Project Directory cd django-Customer-Relation-Management
# Create a Virtual Environment python3 -m venv env
# Activate Virtual Environment source env/bin/activate
# Install Requirements Package pip install -r requirements.txt
# Migrate Database python manage.py migrate
# Create Super User python manage.py createsuperuser
# Finally Run The Project python manage.py runserver
